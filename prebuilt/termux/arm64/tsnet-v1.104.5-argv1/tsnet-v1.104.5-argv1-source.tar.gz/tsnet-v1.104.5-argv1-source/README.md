# tsnet v1.104.5 argv1 candidate: corresponding source

This archive contains the exact sidecar source, tests, build recipe, patched
Tailscale v1.104.5 tree and original licenses for the new candidate binary.
The two Android localapi ACME build-tag changes remain in ANDROID_ACME.patch.
The official archive's .stignore symlink is materialized as .gitignore bytes.

The 27 externally versioned Go modules and Go license/patent notices are
unchanged from the candidate's companion archive ../tsnet-v1.104.4-source.tar.gz
(SHA-256 f5a17e6896c1ba42f21f860a09614c29a21b48a9e2878eeee6fd42ccd0bdece7).
Use its module-sources/ directories together with this archive; the old
Tailscale tree and sidecar in that archive are NOT the candidate source.
The module directories are source distributions, not a prepared Go module cache.
Normal Go dependency resolution may need public downloads if the cache is empty.

Use Go 1.27.3 and the command in BUILD_MANIFEST.json from native/tsnet.
Do not run the normal start mode as an offline test. Full offline/reproducible
builds from an empty cache have not been established. This is a locally built
experimental binary, not an official Tailscale release artifact.
No APK state, auth keys, account identity or user chat data is included.
