# Existing tsnet v1.104.4 binary: corresponding source

This source archive accompanies libpocketrisu_tsnet_exec.so (SHA-256
c9b5c75f4c9792b79b1f840986582289d2ff1ad822e88fc2206b1a551fe5a71b).
The executable was copied unchanged; it was not rebuilt for this distribution.

The PocketRisu-Android source snapshot is commit
a67a75217f94c0d756f4066197e9b0a458bdebe6. That repository's LICENSE is GPLv3.
Original copyright, license, patent and notice files are retained. Tailscale
and the other modules retain their respective licenses. This archive contains
the sidecar sources and tests, the patched local Tailscale source, exact Go
module sources linked into the executable, version/patch/build records, and
the Go toolchain license/patent notices. It contains no APK data or device state.

The upstream build uses Go 1.27.3 and this command in native/tsnet:

    GOFLAGS='' GOWORK=off CGO_ENABLED=0 GOOS=android GOARCH=arm64 go build \
      -buildvcs=false -mod=readonly -trimpath -ldflags='-s -w' \
      -o libpocketrisu_tsnet_exec.so .

Run it from pocketrisu-android/native/tsnet with Go 1.27.3 installed. go.mod
selects ./third_party/tailscale; do not substitute an unpatched release.
go.mod/go.sum retain the original dependency selections and integrity values.
module-sources/ contains the exact 27 externally versioned modules reported by
the binary's Go build information. These source directories are supplied for
inspection/modification and are not preconfigured as an offline Go module cache.
The original broader APK build scripts are retained as provenance; their
cloudflared/APK steps are not needed for the standalone tsnet command above.

This preparation did not execute the command, rebuild the executable, or prove
bit-for-bit rebuild reproducibility. The source/manifest and binary build-info
checks are described in the surrounding provenance and smoke-test documents.
