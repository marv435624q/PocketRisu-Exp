# PocketRisu-Exp tsnet v1.104.5 cert1 corresponding source

This is a custom build, not an official Tailscale distribution binary.
Go 1.27.3, Tailscale v1.104.5 with Android ACME tags, lazy missing server
Noise key loading for SetDNS, and optional existing-registration login guard.
Termux argv normalization is preserved. See the three patch files and tests.

Together with this archive, use module-sources/ in ../tsnet-v1.104.4-source.tar.gz
(SHA-256 f5a17e6896c1ba42f21f860a09614c29a21b48a9e2878eeee6fd42ccd0bdece7)
for the identical 27 externally versioned linked Go modules and Go notices.
Do not substitute the old Tailscale/sidecar sources from that older archive.
The linked module path/version/h1 list is unchanged from argv1.

From native/tsnet use the command/flags in BUILD_MANIFEST.json. The fingerprint
helper resolves its checkout root from scripts/termux and includes all vendor
files, production sidecar sources, go.mod/go.sum, CANDIDATE.json, and the two
build scripts. SOURCE.json and generated outputs are excluded to avoid cycles.
In a Git checkout, prepare-tsnet-source.py restores this exact archived vendor.
This archive already has the vendor; SOURCE.json is intentionally external.
An empty-cache offline build or independent reproducible rebuild is unproven.

No account/device state, auth URL, credentials or private user logs are included.
New candidate Termux login/certificate/HTTPS operation remains unverified.
